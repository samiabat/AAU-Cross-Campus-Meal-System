import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-sucess',
  templateUrl: './verify-sucess.component.html',
  styleUrls: ['./verify-sucess.component.css']
})
export class VerifySucessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
